package com.example.testmpit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu);
        getSupportActionBar().hide();
    }
    SimpleAdapter ad;

    public void GetData(View v) throws SQLException {
        ListView lstv = (ListView) findViewById(R.id.ListView1);

        List<Map<String,String>> MyDataList= null;
        ListItem MyData = new ListItem();
        MyDataList = MyData.getlist();

        String[] Fromw = {"ID_list","Title_list","Text_list"};
        int[] Tow = {R.id.ID_list,R.id.Title_list,R.id.Text_list};
        ad = new SimpleAdapter(MainActivity.this,MyDataList,R.layout.listbase,Fromw,Tow);
        lstv.setAdapter(ad);
    }
}